# Frontend (React + Vite)
    npm install && cp .env.example .env && npm run dev   # http://localhost:5173
Reads live data from the backend WebSocket (`useLive.js`) and REST (`api.js`). Never touches the database.
Pages stubbed in `src/pages/Placeholder.jsx` are yours to build; data is already in the snapshot.
