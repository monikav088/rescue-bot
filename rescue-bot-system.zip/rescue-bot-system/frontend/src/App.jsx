import { NavLink, Navigate, Route, Routes } from 'react-router-dom'
import useLive from './useLive'; import Dashboard from './pages/Dashboard'; import Communication from './pages/Communication'; import Placeholder from './pages/Placeholder'
const NAV = [['dashboard','Dashboard'],['robots','Robots'],['map','Map'],['vision','Robot Vision'],['communication','Communication'],['victims','Victim Detection'],['logs','Logs'],['settings','Settings']]
export default function App() {
  const live = useLive()
  return (<div className="shell">
    <nav className="side"><div className="brand">RESCUE BOT<small>Command Center</small></div>
      {NAV.map(([p, l]) => <NavLink key={p} to={'/' + p}>{l}</NavLink>)}</nav>
    <main>
      <header className="top"><span>{live.connected ? '● Backend connected' : '○ Backend offline'}</span><span className="mock">MOCK DATA</span></header>
      {!live.data ? <p className="muted">Waiting for backend…</p> : (
        <Routes><Route path="/" element={<Navigate to="/dashboard" />} />
          <Route path="/dashboard" element={<Dashboard d={live.data} />} />
          <Route path="/communication" element={<Communication d={live.data} />} />
          {NAV.filter(([p]) => !['dashboard','communication'].includes(p)).map(([p, l]) => <Route key={p} path={'/' + p} element={<Placeholder title={l} />} />)}
        </Routes>)}
    </main></div>)
}
