import { useEffect, useState } from 'react'; import { WS_URL } from './api'
export default function useLive() {
  const [data, setData] = useState(null); const [connected, setConnected] = useState(false)
  useEffect(() => {
    let ws, timer, closed = false
    const open = () => { ws = new WebSocket(WS_URL)
      ws.onopen = () => setConnected(true)
      ws.onmessage = e => { const m = JSON.parse(e.data); if (m.type === 'snapshot') setData(m.data) }
      ws.onclose = () => { setConnected(false); if (!closed) timer = setTimeout(open, 2000) } }
    open(); return () => { closed = true; clearTimeout(timer); ws && ws.close() }
  }, [])
  return { data, connected }
}
