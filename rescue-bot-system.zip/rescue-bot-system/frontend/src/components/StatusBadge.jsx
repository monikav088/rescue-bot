const ICON = { CONNECTED: '🟢', WEAK: '🟡', LOST: '🔴', RECOVERING: '🔵', RESTORED: '🟢' }
export default function StatusBadge({ state }) { return <span className={'badge ' + state}>{ICON[state]} {state}</span> }
