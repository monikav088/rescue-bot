const API = import.meta.env.VITE_API_URL || 'http://localhost:8000'
export const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:8000/ws'
export async function api(path, opts) {
  const r = await fetch(API + path, { headers: { 'Content-Type': 'application/json' }, ...opts })
  if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail || r.statusText)
  return r.json()
}
export const post = (p, body) => api(p, { method: 'POST', body: body ? JSON.stringify(body) : undefined })
