import { useEffect, useState } from 'react'; import StatusBadge from '../components/StatusBadge'; import { api, post } from '../api'
export default function Communication({ d }) {
  const c = d.communication; const [h, setH] = useState([]); const [err, setErr] = useState('')
  useEffect(() => { api('/api/communication/history').then(setH).catch(e => setErr(e.message)) }, [c.state])
  return (<div><h1>Communication</h1><StatusBadge state={c.state} />
    <pre className="path">{c.relay_active ? 'STATION → ROBOT B → ROBOT A' : 'STATION → ROBOT A'}</pre>
    <p>Path {c.path} · Signal {c.signal}% · Relay {c.relay_active ? 'ACTIVE' : 'INACTIVE'}</p>
    <button onClick={() => post('/api/communication/recovery').catch(e => setErr(e.message))}>Trigger relay recovery</button>{err && <p className="alert">{err}</p>}
    <table><thead><tr><th>Time</th><th>Event</th><th>From</th><th>To</th><th>Action</th></tr></thead>
      <tbody>{h.map((e, i) => <tr key={i}><td>{e.ts.slice(11, 19)}</td><td>{e.event}</td><td>{e.prev_state}</td><td>{e.new_state}</td><td>{e.action}</td></tr>)}</tbody></table></div>)
}
