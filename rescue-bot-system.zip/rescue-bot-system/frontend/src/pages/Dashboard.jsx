import { Link } from 'react-router-dom'; import StatusBadge from '../components/StatusBadge'; import { post } from '../api'
export default function Dashboard({ d }) {
  const c = d.communication
  return (<div><h1>Dashboard</h1>
    <section className="comm"><StatusBadge state={c.state} />
      <b>{c.path}</b><span>{c.path === 'RELAY' || c.relay_active ? 'Station → Robot B → Robot A' : 'Station → Robot A'}</span><span>Signal {c.signal}%</span></section>
    <div className="grid">{d.robots.map(r => (
      <Link key={r.id} to="/robots" className="card"><h3>{r.name}</h3>
        <p>{r.online ? 'ONLINE' : 'OFFLINE'} · Battery {r.battery.toFixed(0)}% · Signal {r.signal}%</p>
        <p>Mode {r.mode} · ({r.x.toFixed(0)}, {r.y.toFixed(0)})</p></Link>))}</div>
    <h3>Active alerts</h3>{d.alerts.length ? d.alerts.map((a, i) => <p key={i} className="alert">⚠ {a}</p>) : <p className="muted">No active alerts</p>}
    <button className="estop" onClick={() => ['A','B'].forEach(i => post(`/api/robots/${i}/stop`))}>EMERGENCY STOP</button></div>)
}
