export default function Placeholder({ title }) { return <div><h1>{title}</h1><p className="muted">Not built yet. Backend endpoints are ready; see documentation/API_CONTRACT.md.</p></div> }
