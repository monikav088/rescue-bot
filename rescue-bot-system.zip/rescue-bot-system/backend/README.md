# Backend (FastAPI)
    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    cp .env.example .env
    uvicorn app.main:app --reload --port 8000
Docs: http://localhost:8000/docs . SQLite tables are created on startup. All data is MOCK (app/simulation.py).
Replace `Sim` with hardware adapters (ESP32/LoRa/CSI) later; keep schemas stable.
