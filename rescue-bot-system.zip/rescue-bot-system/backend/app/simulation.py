"""MOCK simulation. Replace with services/hardware.py adapters for real robots (ESP32, LoRa...)."""
import asyncio, math, random, datetime as dt
from .db import Session, CommEvent, LogEntry
STATION = (10.0, 50.0)
def link(a, b): return max(0.0, 100 - 1.4 * math.dist(a, b))
class Sim:
    def __init__(self):
        self.t = 0
        self.robots = {
            "A": dict(id="A", name="Robot A (Scout)", online=True, battery=92.0, signal=100.0, x=20.0, y=50.0, speed=0.0, mode="auto"),
            "B": dict(id="B", name="Robot B (Relay)", online=True, battery=88.0, signal=100.0, x=12.0, y=50.0, speed=0.0, mode="auto"),
        }
        self.comm = dict(state="CONNECTED", path="DIRECT", signal=100.0, relay_active=False, relay_target=None)
        self.victims, self.alerts, self.subs = [], [], set()
        self.hold = 0
    def _log(self, cat, sev, src, desc):
        with Session() as s: s.add(LogEntry(category=cat, severity=sev, source=src, description=desc)); s.commit()
    def _set(self, new, event, action):
        old = self.comm["state"]
        if old == new: return
        self.comm["state"] = new
        with Session() as s: s.add(CommEvent(event=event, prev_state=old, new_state=new, action=action)); s.commit()
        self._log("communication", "warning" if new in ("WEAK", "LOST") else "info", "comm", f"{old} -> {new}: {event}")
    def tick(self):
        self.t += 1
        A, B = self.robots["A"], self.robots["B"]
        if A["mode"] == "auto":
            ox, oy = A["x"], A["y"]
            A["x"] = 10 + 70 * (0.5 + 0.5 * math.sin(self.t / 30)); A["y"] = 50 + 20 * math.sin(self.t / 17)
            A["speed"] = round(math.dist((ox, oy), (A["x"], A["y"])), 2)
        for r in (A, B): r["battery"] = max(0, r["battery"] - 0.02)
        pa = (A["x"], A["y"]); pb = (B["x"], B["y"])
        direct = link(STATION, pa) + random.uniform(-2, 2)
        c = self.comm
        if c["relay_active"]:
            mid = ((STATION[0] + pa[0]) / 2, (STATION[1] + pa[1]) / 2); c["relay_target"] = list(mid)
            d = math.dist(pb, mid)
            if d > 0.5 and B["mode"] == "auto":
                B["x"] += (mid[0] - pb[0]) / d * min(2, d); B["y"] += (mid[1] - pb[1]) / d * min(2, d); B["speed"] = 2.0
            else: B["speed"] = 0.0
            sig = min(link(STATION, (B["x"], B["y"])), link((B["x"], B["y"]), pa))
        else: sig = direct
        c["signal"] = round(max(0, min(100, sig)), 1); A["signal"] = c["signal"]
        B["signal"] = round(link(STATION, (B["x"], B["y"])), 1)
        st = c["state"]
        if not c["relay_active"]:
            if direct < 30 and st != "LOST": self._set("LOST", "Link to Robot A lost", "Triggering relay recovery")
            elif 30 <= direct < 60 and st in ("CONNECTED", "RESTORED"): self._set("WEAK", "Signal degraded", "Monitoring")
            if c["state"] == "LOST": self.start_recovery()
        else:
            if st == "RECOVERING" and c["signal"] >= 60:
                self._set("RESTORED", "Relay path established", "Robot B in position"); c["path"] = "RELAY"; self.hold = 3
            elif st == "RESTORED":
                self.hold -= 1
                if self.hold <= 0: self._set("CONNECTED", "Link stable", "None")
            elif direct >= 75 and st == "CONNECTED":
                c["relay_active"] = False; c["path"] = "DIRECT"; c["relay_target"] = None
                self._log("communication", "info", "Robot B", "Relay deactivated, direct link healthy")
        if self.t % 90 == 45 and len(self.victims) < 3:
            v = dict(id=len(self.victims) + 1, x=round(random.uniform(30, 85), 1), y=round(random.uniform(30, 75), 1), zone=random.choice(["Zone 1", "Zone 2", "Zone 3"]),
                     confidence=round(random.uniform(.7, .97), 2), source=random.choice(["camera", "wifi_csi"]), status="detected", ts=dt.datetime.utcnow().isoformat())
            self.victims.append(v); self.alerts.append(f"Victim detected in {v['zone']} ({int(v['confidence']*100)}%)"); self._log("victim", "warning", v["source"], f"Victim detected in {v['zone']}")
        self.alerts = self.alerts[-5:]
    def start_recovery(self, manual=False):
        c = self.comm
        if c["relay_active"]: return False
        c["relay_active"] = True; self._log("communication", "warning", "Robot B", "Relay activated, repositioning")
        old = c["state"]; c["state"] = "RECOVERING"
        with Session() as s: s.add(CommEvent(event="Relay recovery initiated", prev_state=old, new_state="RECOVERING", action="Robot B repositioning")); s.commit()
        return True
    def snapshot(self):
        return dict(robots=list(self.robots.values()), communication=self.comm, victims=self.victims, alerts=self.alerts,
                    map=dict(station=STATION), data_source="MOCK")
    async def run(self):
        while True:
            self.tick(); snap = {"type": "snapshot", "data": self.snapshot()}
            for ws in list(self.subs):
                try: await ws.send_json(snap)
                except Exception: self.subs.discard(ws)
            await asyncio.sleep(1)
sim = Sim()
