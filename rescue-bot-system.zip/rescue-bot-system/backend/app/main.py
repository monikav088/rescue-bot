import os, asyncio
from fastapi import FastAPI, APIRouter, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from .db import init_db, Session, CommEvent, LogEntry
from .simulation import sim
from . import schemas as S
app = FastAPI(title="Rescue Bot Command Center API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:5173").split(","), allow_methods=["*"], allow_headers=["*"])
api = APIRouter(prefix="/api")
def robot(rid):
    if rid not in sim.robots: raise HTTPException(404, f"Robot {rid} not found")
    return sim.robots[rid]
@api.get("/robots", response_model=list[S.Robot])
def robots(): return list(sim.robots.values())
@api.get("/robots/{rid}", response_model=S.Robot)
def get_robot(rid: str): return robot(rid.upper())
@api.post("/robots/{rid}/move", response_model=S.Ack)
def move(rid: str, req: S.MoveRequest):
    r = robot(rid.upper()); r["mode"] = "manual"
    dx, dy = {"forward": (0, -3), "backward": (0, 3), "left": (-3, 0), "right": (3, 0)}[req.direction]
    r["x"] += dx; r["y"] += dy; r["speed"] = 3.0
    sim._log("robot", "info", rid.upper(), f"Move {req.direction} (MOCK)")
    return S.Ack(message=f"Robot {rid.upper()} moving {req.direction} [MOCK]")
@api.post("/robots/{rid}/stop", response_model=S.Ack)
def stop(rid: str):
    r = robot(rid.upper()); r["speed"] = 0.0; r["mode"] = "manual"
    sim._log("robot", "warning", rid.upper(), "STOP command"); return S.Ack(message="Stopped")
@api.post("/robots/A/arm", response_model=S.Ack)
def arm(req: S.ArmRequest):
    sim._log("robot", "info", "A", f"Arm {req.action} (MOCK)"); return S.Ack(message=f"Arm {req.action} [MOCK]")
@api.get("/communication", response_model=S.Communication)
def communication(): return sim.comm
@api.get("/communication/history", response_model=list[S.CommEventOut])
def history():
    with Session() as s:
        rows = s.query(CommEvent).order_by(CommEvent.id.desc()).limit(100).all()
        return [S.CommEventOut(ts=r.ts.isoformat(), event=r.event, prev_state=r.prev_state, new_state=r.new_state, action=r.action) for r in rows]
@api.post("/communication/recovery", response_model=S.Ack)
def recovery():
    if not sim.start_recovery(): raise HTTPException(409, "Relay recovery already active")
    return S.Ack(message="Relay recovery initiated")
@api.get("/victims", response_model=list[S.Victim])
def victims(): return sim.victims
@api.get("/logs", response_model=list[S.LogOut])
def logs(category: str | None = None):
    with Session() as s:
        q = s.query(LogEntry)
        if category: q = q.filter(LogEntry.category == category)
        return [S.LogOut(ts=r.ts.isoformat(), category=r.category, severity=r.severity, source=r.source, description=r.description) for r in q.order_by(LogEntry.id.desc()).limit(200)]
@api.get("/map")
def map_(): return sim.snapshot()
app.include_router(api)
@app.websocket("/ws")
async def ws(ws: WebSocket):
    await ws.accept(); sim.subs.add(ws)
    try:
        await ws.send_json({"type": "snapshot", "data": sim.snapshot()})
        while True: await ws.receive_text()
    except WebSocketDisconnect: sim.subs.discard(ws)
@app.on_event("startup")
async def start(): init_db(); asyncio.create_task(sim.run())
