import os, datetime as dt
from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker
engine = create_engine(os.getenv("DATABASE_URL", "sqlite:///./rescue.db"), connect_args={"check_same_thread": False})
Session = sessionmaker(bind=engine)
Base = declarative_base()
class CommEvent(Base):
    __tablename__ = "comm_events"
    id = Column(Integer, primary_key=True); ts = Column(DateTime, default=dt.datetime.utcnow)
    event = Column(String); prev_state = Column(String); new_state = Column(String); action = Column(String)
class LogEntry(Base):
    __tablename__ = "logs"
    id = Column(Integer, primary_key=True); ts = Column(DateTime, default=dt.datetime.utcnow)
    category = Column(String); severity = Column(String); source = Column(String); description = Column(String)
def init_db(): Base.metadata.create_all(engine)
