from typing import Literal, Optional
from pydantic import BaseModel
CommState = Literal["CONNECTED", "WEAK", "LOST", "RECOVERING", "RESTORED"]
class MoveRequest(BaseModel):
    direction: Literal["forward", "backward", "left", "right"]
class ArmRequest(BaseModel):
    action: Literal["up", "down", "gripper_open", "gripper_close", "stop"]
class Ack(BaseModel):
    ok: bool = True
    message: str
class Robot(BaseModel):
    id: Literal["A", "B"]; name: str; online: bool; battery: float; signal: float
    x: float; y: float; speed: float; mode: Literal["manual", "auto"]; data_source: str = "MOCK"
class Communication(BaseModel):
    state: CommState; path: Literal["DIRECT", "RELAY"]; signal: float; relay_active: bool
    relay_target: Optional[list[float]] = None
class CommEventOut(BaseModel):
    ts: str; event: str; prev_state: str; new_state: str; action: str
class Victim(BaseModel):
    id: int; x: float; y: float; zone: str; confidence: float; source: str; status: str; ts: str
class LogOut(BaseModel):
    ts: str; category: str; severity: str; source: str; description: str
