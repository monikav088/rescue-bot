# API Contract (v0.1) — base `http://localhost:8000`, no auth yet (placeholder: add `Authorization: Bearer` later)
| Method | URL | Body | Response |
|---|---|---|---|
| GET | /api/robots | – | Robot[] |
| GET | /api/robots/{A\|B} | – | Robot (404 if unknown) |
| POST | /api/robots/{A\|B}/move | `{"direction":"forward\|backward\|left\|right"}` | `{ok,message}` |
| POST | /api/robots/{A\|B}/stop | – | `{ok,message}` |
| POST | /api/robots/A/arm | `{"action":"up\|down\|gripper_open\|gripper_close\|stop"}` | `{ok,message}` |
| GET | /api/communication | – | `{state,path,signal,relay_active,relay_target}` |
| GET | /api/communication/history | – | `[{ts,event,prev_state,new_state,action}]` |
| POST | /api/communication/recovery | – | `{ok,message}`; 409 if already active |
| GET | /api/victims | – | Victim[] |
| GET | /api/logs?category= | – | `[{ts,category,severity,source,description}]` |
| GET | /api/map | – | snapshot (below) |

Errors: `{"detail":"..."}` with 404/409/422.
Robot: `{id,name,online,battery,signal,x,y,speed,mode,data_source}`. States: CONNECTED, WEAK, LOST, RECOVERING, RESTORED.

## WebSocket `ws://localhost:8000/ws`
Server pushes every second: `{"type":"snapshot","data":{robots,communication,victims,alerts,map:{station:[x,y]},data_source:"MOCK"}}`.
Client sends nothing (keep-alive text optional).

## Flow
Frontend → REST → FastAPI → simulation/DB.  Frontend ⇄ WebSocket ⇄ FastAPI ⇄ real-time robot events.
