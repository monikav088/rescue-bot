# Architecture
- `backend/app/simulation.py`: MOCK robots + communication state machine (CONNECTED→WEAK→LOST→RECOVERING→RESTORED). Replace with hardware adapters (ESP32, LoRa, camera, Wi-Fi CSI) behind the same snapshot shape.
- `db.py`: SQLite via SQLAlchemy (comm_events, logs). `schemas.py`: Pydantic contract. `main.py`: REST + WebSocket.
- Frontend only uses REST + WS. Wi-Fi CSI detections should become entries in `victims` with `source:"wifi_csi"`.
## Git workflow
`main` protected; branches `backend/*` (backend dev) and `frontend/*` (teammate). Each dev edits only their folder; change `documentation/API_CONTRACT.md` via PR reviewed by both.
