# Rescue Bot Command Center
Disaster-rescue robot control prototype. Robot A (4-wheel scout + arm), Robot B (3-wheel relay). **All robot data is simulated; no hardware is integrated.**
Run: backend (`backend/README.md`) on :8000, frontend (`frontend/README.md`) on :5173. Docs in `documentation/`.
